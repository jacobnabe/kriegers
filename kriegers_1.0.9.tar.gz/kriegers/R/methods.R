# Author: Jacob Nabe-Nielsen
# Date: 2014-03-20
# Description: Code for intrapolating tracks (either by distributing points 
# evenly separated in time or in space along a track) and for testing and
# analyzing the tracks.


check.input <- function(object, ...) attributes(object)
setGeneric("check.input")

setMethod("check.input", "data.frame",
	function(object) {
		if(!("D_DATE") %in% names(object)) stop("Input must contain the column D_DATE")
		if(!("LAT") %in% names(object)) stop("Input must contain the column LAT")
		if(!("LON") %in% names(object)) stop("Input must contain the column LON")
		good.obj <- TRUE
		df.lgt <- length(object[,1])
		d.date <- as.numeric(object$D_DATE [2:df.lgt] - object$D_DATE [1:(df.lgt-1)])
		err.lns <- paste(which(d.date<0), collapse=", ")
		if(sum(d.date<0)>0) {
			warning(paste("D_DATE < 0 (track moves back in time) for line(s): ", err.lns, ".", sep=""))
			ttt <- order(object$D_DATE)
			object <- object[ttt ,]
			good.obj <- FALSE
			# sorted track returned invisibly
		}
		if (!any(class(object$D_DATE)=="POSIXct")) {
			object$D_DATE <- as.POSIXct(object$D_DATE)
			message("D_DATE must be of class as.POSIXct, corrected object returned")
			good.obj <- FALSE
		}
		if (!class(object$LAT)=="numeric") {
			object$LAT <- as.numeric(as.character(object$LAT))
			message("LAT must be of numeric, corrected object returned")
			good.obj <- FALSE
		}
		if (!class(object$LON)=="numeric") {
			object$LON <- as.numeric(as.character(object$LON))
			message("LON must be of numeric, corrected object returned")
			good.obj <- FALSE
		}
		if (good.obj) message("Track can be converted with wgs84.to.utm")
		else invisible(object)
	}
)


setMethod("check.input", "SpatialPointsDataFrame",
	function(object) {
		print("Input must be a data frame")
	}
)



as.SpatialPointsDataFrame <- function(object, crs) attributes(object)
setGeneric("as.SpatialPointsDataFrame")

# crs=" +proj=utm +zone=32 +ellps=GRS80 +units=m +no_defs"

setMethod("as.SpatialPointsDataFrame", "data.frame",
	function(object, crs) {
		# Convert utm data frame to utm SpatialPointsDataFrame
		# crs string taken from data(denmark)
		if (class(crs) != "character") stop("crs must be of class 'character'")
		names(object)[which(names(object)=="x")] <- "coords.x1"
		names(object)[which(names(object)=="y")] <- "coords.x2"
		if(!("coords.x1" %in% names(object)) ) stop("either x or coords.x1 must be a column in the input")
		if(!("coords.x2" %in% names(object)) ) stop("either y or coords.x2 must be a column in the input")
		# Convert positions to spatial points data frame
		object <- object[!is.na(object$coords.x1) & !is.na(object$coords.x2) ,]
		if("D_DATE" %in% names(object)) object$D_DATE <- as.POSIXct(as.character(object$D_DATE))
		vv2 <- SpatialPoints(cbind(object$coords.x1, object$coords.x2), proj4string = CRS(crs))
		vv3 <- SpatialPointsDataFrame(vv2, object[, setdiff(names(object), c("coords.x1", "coords.x2"))])
		object.utm <- spTransform(vv3, CRS(crs))
		return(object.utm)
	}
)



wgs84.to.utm <- function(object, ...) attributes(object)
setGeneric("wgs84.to.utm")


setMethod("wgs84.to.utm", "data.frame",
	function(object, crs=" +proj=utm +zone=32 +ellps=GRS80 +units=m +no_defs",
		return.type="spdf") {
		# Convert data frame to utm SpatialPointsDataFrame
		# crs string taken from data(denmark)
		if(!("LON" %in% names(object)) ) stop("LON must be a column in the input")
		if(!("LAT" %in% names(object)) ) stop("LAT must be a column in the input")
		# Convert positions to spatial points data frame
		object <- object[!is.na(object$LON) & !is.na(object$LAT) ,]
		vv2 <- SpatialPoints(cbind(object$LON, object$LAT), proj4string = CRS("+proj=longlat +datum=WGS84"))
		vv3 <- SpatialPointsDataFrame(vv2, object[, setdiff(names(object), c("LON", "LAT"))])
		object.utm <- spTransform(vv3, CRS(crs))
		if (return.type=="spdf") return(object.utm)
		else if (return.type=="df") return(as.data.frame(object.utm))
		else stop("Unknown required return format (return.type must be 'spdf' or 'df')")
	}
)


setMethod("wgs84.to.utm", "SpatialPointsDataFrame",
	function(object, return.type="spdf") {
		crs=proj4string(object)
		# Convert SpatialPointsDataFrame to utm SpatialPointsDataFrame
		object.utm <- spTransform(object, CRS(crs))
		if (return.type=="spdf") return(object.utm)
		else if (return.type=="df") return(as.data.frame(object.utm))
		else stop("Unknown required return format (return.type must be 'spdf' or 'df')")
	}
)


utm.to.wgs84 <- function(object, ...) attributes(object)
setGeneric("utm.to.wgs84")


setMethod("utm.to.wgs84", "data.frame",
	function(object, crs=" +proj=utm +zone=32 +ellps=GRS80 +units=m +no_defs", 
		return.type="spdf") {  
		# Convert utm-projected SpatialPointsDataFrame to lat-long data frame
		# crs string taken from data(denmark)
		# convert to spdf
		if(!("coords.x1" %in% names(object)) ) stop("'coords.x1' must be a column in the input")
		if(!("coords.x2" %in% names(object)) ) stop("'coords.x2' must be a column in the input")
		# Convert positions to spatial points data frame	
		vv2 <- SpatialPoints(cbind(object$coords.x1, object$coords.x2), proj4string = CRS(crs))
		vv3 <- SpatialPointsDataFrame(vv2, object[, setdiff(names(object), c("x", "y"))])
		object.wgs <- spTransform(vv3, CRS("+proj=longlat +datum=WGS84"))
		if (return.type=="spdf") return(object.wgs)
		else if (return.type=="df") return(as.data.frame(object.wgs))
		else stop("Unknown required return format (return.type must be 'spdf' or 'df')")
	}
)


setMethod("utm.to.wgs84", "SpatialPointsDataFrame",
	function(object, crs=" +proj=utm +zone=32 +ellps=GRS80 +units=m +no_defs", 
		return.type="spdf") {  
		# Convert utm-projected SpatialPointsDataFrame to lat-long data frame
		# crs string taken from data(denmark)
		# convert to spdf if needed
		object.wgs <- spTransform(object, CRS("+proj=longlat +datum=WGS84"))
		if (return.type=="spdf") return(object.wgs)
		else if (return.type=="df") return(as.data.frame(object.wgs))
		else stop("Unknown required return format (return.type must be 'spdf' or 'df')")
	}
)


.get.pos <- function(object, ...) attributes(object)
setGeneric(".get.pos")

setMethod(".get.pos", "data.frame",
	function(object, last.pos, current.pos.no, dist.to.move, debug=FALSE, seg=NA) {
		# Function used in 'interp.pos.dist'
		# Obtain positions that are evenly distributed in space based on linear intapolation
		# (that is, walk ds [=sample dist] along track and get new pos and time)
		# Assumes that D_DATE gives the sampling time?
		#
		# Use linear intrapolation to get one-line data frame with time and position
		# last.pos is a data frame with D_DATE, x and y of the last gps position the animal passed
		if(dist.to.move < 0) stop("The distance to move must be >0 and <length of obs move")
		if(!all(c("ref", "D_DATE", "coords.x1", "coords.x2") %in% names(object))) stop ("The object must contain the columns 'ref', 'D_DATE', 'coords.x1' and 'coords.x2'")
		if(current.pos.no >= length(object[,1])) stop("Cannot calculate more steps, have reached end of track")
		dx <- object$coords.x1[current.pos.no+1] - last.pos$x
		dy <- object$coords.x2[current.pos.no+1] - last.pos$y
		lgt.of.next.obs.move <- sqrt(dx^2 + dy^2)
		# if (debug) message (paste("\nDist remaining in ds step:", dist.to.move)) 
		# if (debug) message (paste("Length of next obs move:", lgt.of.next.obs.move))  # ok, going to this pos is too far
		if(lgt.of.next.obs.move < dist.to.move) stop("This function should be called for intrapolation only")
		rel <- dy / dx
		dx.new <- sqrt(dist.to.move^2 / (1 + rel^2))
		dx.new <- ifelse(dx<0, -dx.new, dx.new)
		dy.new <- rel * dx.new
		next.pos.x <- last.pos$x + dx.new
		next.pos.y <- last.pos$y + dy.new
		next.pos.time <- last.pos$D_DATE + 
			(dist.to.move / lgt.of.next.obs.move) * 60 * as.numeric(object$D_DATE[current.pos.no+1] - last.pos$D_DATE)  # time in hours
		# if (debug) message (paste("dt:", next.pos.time - last.pos$D_DATE))
		return(data.frame("ref"= levels(as.factor(object$ref[1])), "D_DATE"=next.pos.time, "x"=next.pos.x, "y"=next.pos.y, "burst"=seg))
	}
)


interp.pos.dist <- function(object, ds, ...) attributes(object)
setGeneric("interp.pos.dist")

setMethod("interp.pos.dist", "SpatialPointsDataFrame",
	function(object, ds, max.dt=120, date.min="1980-01-01", date.max="2040-01-01", 
	start.burst=1, debug=FALSE) {
		# ds is the distance between positions in the output track (measured along the track)
		# dt is the maximum allowed time between pos (in minutes)
		# date.min and date.max can be either mm-dd or yyyy-mm-dd. In the first case the period is used irrespecitve of year
		# if (class(object) != "SpatialPointsDataFrame") stop("object must be a SpatialPointsDataFrame")
		if(length(grep("utm", proj4string(object), ignore.case=TRUE))<1) stop("Input object must use UTM coordinates")
		one.track.utm.df <- as.data.frame(object)
		if(!("D_DATE" %in% names(one.track.utm.df))) stop("Column D_DATE missing")
		# On windows the as.data.frame gives the names x and y, must be converted
		names(one.track.utm.df)[which(names(one.track.utm.df)=="x")] <- "coords.x1"
		names(one.track.utm.df)[which(names(one.track.utm.df)=="y")] <- "coords.x2"
		if(!("coords.x1" %in% names(one.track.utm.df))) stop("Column coords.x1 missing")
		if(!("coords.x2" %in% names(one.track.utm.df))) stop("Column coords.x2 missing")
		# Select subset of data to work on:
		if (!( (nchar(date.min)==5 && nchar(date.max)==5) || (nchar(date.min)==10 && nchar(date.max)==10) )) {
			stop("date.min and date.max should both be in the format yyyy-mm-dd or mm-dd")
		}
		if (nchar(date.min)==10 && nchar(date.max)==10) {
			d.min <- as.POSIXct(date.min)
			d.max <- as.POSIXct(date.max)
			one.track.utm.df <- one.track.utm.df[one.track.utm.df$D_DATE >= d.min & one.track.utm.df$D_DATE < d.max ,]
		} else {
			min.doy <- as.POSIXlt(paste("1980-", date.min, sep=""))$yday
			max.doy <- as.POSIXlt(paste("1980-", date.max, sep=""))$yday
			if(min.doy<max.doy) {
				one.track.utm.df <- one.track.utm.df[as.POSIXlt(one.track.utm.df$D_DATE)$yday >= min.doy & 
					as.POSIXlt(one.track.utm.df$D_DATE)$yday < max.doy ,]
			} else { # That is, for the winter period - spanning new year
				one.track.utm.df <- one.track.utm.df[as.POSIXlt(one.track.utm.df$D_DATE)$yday >= min.doy | 
					as.POSIXlt(one.track.utm.df$D_DATE)$yday < max.doy ,]			
			}
		}	
		# Interpolate
		one.track.new <- data.frame()
		burst <- start.burst-1  # number of the track burst interrupted by gaps shorter than max.dt
		for(ref in unique(as.character(one.track.utm.df$ref))) {
			# Sample new pos for particular ref -- add it to new data frame "one.track.new"
			message(paste(ref, "interpolated"))
			burst <- burst + 1
			one.tr <- one.track.utm.df[as.character(one.track.utm.df$ref)==ref ,]
			one.track.new <- rbind(one.track.new, data.frame("ref"=as.character(one.tr$ref[1]), 
				"D_DATE"=one.tr$D_DATE[1], "x"=one.tr$coords.x1[1], "y"=one.tr$coords.x2[1],
				"burst" = burst)
			)
			last.obs.pos.no <- 1
			current.pos <- c(one.tr[1, c("ref", "D_DATE","coords.x1","coords.x2")], burst)
			names(current.pos) <- c("ref", "D_DATE","x","y", "burst")
			# Test if time diff to next pos is too long
			nn <- length(one.tr[,1])
			dt2 <- difftime(one.tr$D_DATE[2:nn], one.tr$D_DATE[1:(nn-1)], units="mins")
			t.to.next.obs <- c(as.numeric(dt2), NA)
			rows.w.long.time.steps <- which(t.to.next.obs > max.dt)
			if(any(which(t.to.next.obs < 0))) stop(paste("Time step < 0 in line", which(t.to.next.obs < 0)))
			while(last.obs.pos.no < length(one.tr[,1])) {
				if(last.obs.pos.no %in% rows.w.long.time.steps) {
					if(debug) message(paste("\n", ref, "moving to pos", 1+last.obs.pos.no))	
					burst <- burst + 1
					last.obs.pos.no <- last.obs.pos.no + 1
					current.pos <- c(one.tr[last.obs.pos.no, c("ref", "D_DATE","coords.x1","coords.x2")], burst)
					names(current.pos) <- c("ref", "D_DATE","x","y", "burst")
					one.track.new <- rbind(one.track.new, current.pos)
					next
				}
				dist.moved.this.step <- 0
				while (dist.moved.this.step < ds && last.obs.pos.no < length(one.tr[,1])) {
					dx.obs <- one.tr$coords.x1[last.obs.pos.no+1] - current.pos$x
					dy.obs <- one.tr$coords.x2[last.obs.pos.no+1] - current.pos$y
					dist.to.next.obs.pos <- sqrt(dx.obs^2 + dy.obs^2)
					if(dist.to.next.obs.pos < ds - dist.moved.this.step) { # then pass next obs pos
						dist.moved.this.step <- dist.moved.this.step + dist.to.next.obs.pos
						last.obs.pos.no <- last.obs.pos.no + 1
						current.pos <- c(one.tr[last.obs.pos.no, c("ref", "D_DATE","coords.x1","coords.x2")], burst)
						names(current.pos) <- c("ref", "D_DATE","x","y", "burst")
						if(debug) message (paste("passing obs pos", last.obs.pos.no)) 
					} else { # that is, if dist to next obs pos needs to be intrapolated
						new.pos <- .get.pos(one.tr, current.pos, last.obs.pos.no, (ds-dist.moved.this.step), 
							debug=TRUE, seg=burst
						)
						one.track.new <- rbind(one.track.new, new.pos)
						current.pos <- new.pos
						if(debug) message ("passing intrap pos") 
						break
					}
				}
			}
	
		} # end for loop
		
		return(one.track.new)
	}
)


setMethod("interp.pos.dist", "data.frame",
	function(object, ds, max.dt=120, date.min="1980-01-01", date.max="2040-01-01", debug=FALSE) {
		stop("Input object must be a SpatialPointsDataFrame")
	}
)


# interp.pos.time <- function(object, ...) attributes(object)
# setGeneric("interp.pos.time")


# setMethod("interp.pos.time", "SpatialPointsDataFrame",
	# function(object, hrs, max.dt=120, date.min="1980-01-01", date.max="2040-01-01", debug=FALSE) {
		# # hrs is a vector with times (decimal hours, 0-23.99999) that should be present in the output track
		# # max.dt is the maximum allowed time between pos (in minutes)
		# hrs <- sort(hrs)
		# if (class(hrs) != "numeric") stop("'hrs' must be a numeric vector")
		# if(max(hrs)>24 || min(hrs)<0) stop("'hrs' must be between 0 and 24")
		# if (class(object) != "SpatialPointsDataFrame") stop("object must be a SpatialPointsDataFrame")
		# if(length(grep("utm", proj4string(object), ignore.case=TRUE))<1) stop("object must use UTM coordinates")
		# object.utm.df <- as.data.frame(object)
		# ## DEBUG -- use just first 50 lines:
		# # object.utm.df <- object.utm.df[1:150 ,]
		# if(!("D_DATE" %in% names(object.utm.df))) stop("Column D_DATE missing")
		# if(!("coords.x1" %in% names(object.utm.df))) stop("Column coords.x1 missing")
		# if(!("coords.x2" %in% names(object.utm.df))) stop("Column coords.x2 missing")
		# # Select subset of data to work on:
		# d.min <- as.POSIXct(date.min)
		# d.max <- as.POSIXct(date.max)
		# object.utm.df <- object.utm.df[object.utm.df$D_DATE >= d.min & object.utm.df$D_DATE <= d.max ,]
		# # Linear interpolation
		# #object.new <- data.frame()
		# burst <- 0  # number of the track burst interrupted by gaps shorter than max.dt
		# d.lgt <- length(object.utm.df$ref)
		# # Decimal hour of observed positions
		# decimal.hrs <- as.numeric(format(object.utm.df$D_DATE, format="%H")) + 
			# as.numeric(format(object.utm.df$D_DATE, format="%M"))/60 + 
			# as.numeric(format(object.utm.df$D_DATE, format="%S")) /(60*60)
		# the.dates <- as.POSIXlt(object.utm.df$D_DATE)
		# the.doys <- the.dates$yday  # extract day of year
		# object.new <- data.frame()  # init output df
		# all.ok.tmp <- rep(FALSE, (length(the.doys)-1))
		# t.after.curr <- t.to.next <- rep(NA, length(all.ok.tmp))
		# for (ii in 1:length(hrs)) {
			# the.hr <- hrs[ii]
			# # is the.hr in the interval between this pos and the next?
			# hrs.after.current <- the.hr >= decimal.hrs[1:(d.lgt-1)]
			# hrs.before.next <- the.hr < decimal.hrs[2:d.lgt] + (the.doys[2:d.lgt]-the.doys[1:(d.lgt-1)]) * 24
			# all.ok.tmp <- (hrs.after.current & hrs.before.next)
			# t.after.curr <- ifelse(is.na(t.after.curr) & all.ok.tmp, the.hr - decimal.hrs[1:(d.lgt-1)], t.after.curr)
			# t.to.next <- ifelse(is.na(t.to.next) & all.ok.tmp, (decimal.hrs[2:d.lgt] + (the.doys[2:d.lgt]-the.doys[1:(d.lgt-1)]) * 24) - the.hr, t.to.next)
			# # workaround for date changes:
			# hrs.after.current[1:(d.lgt-1)] <- ifelse(hrs.before.next[2:d.lgt] & (the.doys[2:d.lgt]-the.doys[1:(d.lgt-1)]), TRUE, FALSE)
			# hrs.before.next[1:(d.lgt-1)] <- the.hr < decimal.hrs[2:d.lgt]
			# # update rows to select:
			# all.ok.tmp <- ifelse((all.ok.tmp | (hrs.after.current & hrs.before.next)), TRUE, FALSE)
			# t.after.curr <- ifelse(is.na(t.after.curr) & all.ok.tmp, the.hr - decimal.hrs[1:(d.lgt-1)], t.after.curr)
			# t.after.curr <- ifelse(t.after.curr<0, t.after.curr+24, t.after.curr)
			# t.to.next <- ifelse(is.na(t.to.next) & all.ok.tmp, (decimal.hrs[2:d.lgt] + (the.doys[2:d.lgt]-the.doys[1:(d.lgt-1)] - 1) * 24) - the.hr, t.to.next)
			# # Check that time between pos is ok
			# dt <- difftime(object.utm.df$D_DATE[2:d.lgt], object.utm.df$D_DATE[1:(d.lgt-1)], units="mins")
			# interval.ok <- dt <= max.dt # too long time to next pos?
			# use.row <- interval.ok & all.ok.tmp
			# ## Produce new track for this value of hrs
			# dx.obs <- object.utm.df$coords.x1[2:d.lgt] - object.utm.df$coords.x1[1:(d.lgt-1)]
			# dy.obs <- object.utm.df$coords.x2[2:d.lgt] - object.utm.df$coords.x2[1:(d.lgt-1)]
			# dx <- object.utm.df$coords.x1[1:(d.lgt-1)] + dx.obs * t.after.curr/(t.after.curr+t.to.next)
			# dy <- object.utm.df$coords.x2[1:(d.lgt-1)] + dy.obs * t.after.curr/(t.after.curr+t.to.next)
			# otud <- object.utm.df[1:length(use.row),]  # last line of df never used
			# object.new <- rbind(object.new, 
				# data.frame(
					# "ref"= otud$ref[use.row], 
					# "D_DATE"= as.POSIXct(otud$D_DATE + t.after.curr*60*60)[use.row],
					# "coords.x1"=dx[use.row], "coords.x2"=dy[use.row]
				# )
			# )
		# }
		# object.new <- object.new[2:length(object.new[,1]),]
		# ix <- order(object.new$ref, object.new$D_DATE)
		# object.new <- object.new[ix,]
		# return(object.new)
	# }
# )


.test.interp.data <- function(object, ...) attributes(object)
setGeneric(".test.interp.data")


setMethod(".test.interp.data", "data.frame",
	function(object) {
		print("Number of positions per burst and track:")
		print(with(object, table(burst, ref)))
		ll <- length(object[,1])
		gaps <- which(object$burst[2:ll] - object$burst[1:(ll-1)]  != 0)
		dts <- NULL
		for (gap in gaps) {
		dt <- difftime(object$D_DATE[gap+1], object$D_DATE[gap], units="mins")
		if(dt>0) dts <- cbind(dts, dt)
		}
		print("\nTime steps at burst shifts [mins]:")
		print(summary(as.numeric(dts)))
	}
)


plot.track.stats <- function(x, ...) attributes(x)
setGeneric("plot.track.stats")


setMethod("plot.track.stats", "SpatialPointsDataFrame",
	function(x) {
		# Plot distribution of time between positions
		# if (class(x) != "SpatialPointsDataFrame") stop("one.spdf must be a SpatialPointsDataFrame")
		if(length(grep("utm", proj4string(x), ignore.case=TRUE))<1) stop("input track must use UTM coordinates")
		n.pos <- dim(x@data)[1]
		x.df <- as.data.frame(x)
		refs <- unique(as.character(x$ref))
		nrefs <- length(refs)
		dev.new(width=4, height=6)
		par(mfcol=c(2, 1), mar=c(4,4.2,2.8,1))
		the.ref <- refs[1]
		x.sel.ref <- x.df[as.character(x.df$ref)==the.ref ,]
		n.pos <- length(x.sel.ref[,1])
		# Time diff in minutes, distance in metres
		t.since.prev <- x.sel.ref$D_DATE[2:n.pos] - x.sel.ref$D_DATE[1:(n.pos-1)]
		t.since.prev <- c(NA, t.since.prev)
		dx <- x.sel.ref$coords.x1[2:n.pos] - x.sel.ref$coords.x1[1:(n.pos-1)]
		dy <- x.sel.ref$coords.x2[2:n.pos] - x.sel.ref$coords.x2[1:(n.pos-1)]
		dist.since.prev <- c(NA, sqrt(dx^2 + dy^2))
		# Plot summary stats
		plot(t.since.prev[t.since.prev>0], dist.since.prev[t.since.prev>0]/1000,   # dist.since.prev is in metres
			log="x",
			xlab=expression(paste("time since prev pos [min]")), 
			ylab=expression(paste("dist since prev pos [km]")),
			pch=16, cex=0.3, main=the.ref
		)
		hist(log10(as.numeric(t.since.prev[t.since.prev>0])),
			main="", xlab=expression(paste(Log[10],"(time since prev pos)"))
		)
	}
)


get.res.t <- function(object, the.rad, ...) attributes(object)
setGeneric("get.res.t")


setMethod("get.res.t", "data.frame",
	function(object, the.rad, unit="days", maxt=1000000) {
		# Convert to object of type ltraj for calculation of residence times (using adehabitatLT)
		# the.rad=radius in m
		# if(class(object) != "data.frame") stop("Input should be a data frame")
		if(!("D_DATE" %in% names(object))) stop("D_DATE should be in the input track data frame")
		if(!("x" %in% names(object))) stop("'x' should be in the input track data frame")
		if(!("y" %in% names(object))) stop("'y' should be in the input track data frame")
		if(!("burst" %in% names(object))) stop("'burst' should be in the input track data frame")
		# require(adehabitatLT)
		one.seal.lt <- as.ltraj(xy= object[,c("x","y")], 
			date= as.POSIXct(object$D_DATE), 
			id=as.character(object$ref), burst=as.character(substr(10000 + object$burst, 2, 9)),
			typeII=TRUE
		)	
		# Calc residence time
		one.file.res.t <- residenceTime(lt=one.seal.lt, radius=the.rad, 
			maxt= maxt, units=unit
		)  # here res time is in seconds  !!!!!!!!!!!!!!!!!!!!
		# convert to data frame
		rt.data <- data.frame()
		prev.id <- 0
		for (ii in 1:length(one.seal.lt)) {
			id <- id(one.seal.lt)[ii]
			burst <- burst(one.seal.lt)[ii]
			n.pos <- length(one.file.res.t[[ii]][,1])
			rt.data <- rbind(rt.data, cbind(id, burst, one.file.res.t[[ii]], "rad"=the.rad, n.pos))
			# output to screen:
			if (id!=prev.id) {
				message(paste(id, "\t", the.rad, "m")); prev.id <- id
			}
		}
		if (!all(object$burst == as.numeric(as.character(one.file.res.t$burst)))) stop("Something wrong with burst in input")
		if (!all(object$D_DATE == one.file.res.t$Date)) stop("Something wrong with date in input")
		rt.data <- cbind(rt.data, "rad"=the.rad, "x"=object$x, "y"=object$y)
		names(rt.data)[4] <- "res.t"
		if (unit=="hours") rt.data$res.t <- rt.data$res.t / (60 * 60)
		if (unit=="days") rt.data$res.t <- rt.data$res.t / (60 * 60 * 24)
		return(rt.data)
	}
)


add.var.from.raster <- function(object, ...) attributes(object)
setGeneric("add.var.from.raster")


setMethod("add.var.from.raster", "data.frame",
	function(object, the.raster, varname="new.var", radius=NA) {
		# Extract value from raster file based on x-y position (assume same proj4string)
		# if radius is not NA and >0, get average value for all cells in radius
		if(!("x" %in% names(object))) stop("'x' should be in the input track data frame")
		if(!("y" %in% names(object))) stop("'y' should be in the input track data frame")
		if(class(the.raster)!="RasterLayer") stop("the.raster should be a RasterLayer")
		ttt <- cbind(object, "xxx"=NA)
		head(ttt)

		if (is.na(radius)) {
			ttt$xxx <- extract(the.raster, matrix(data=c(ttt$x, ttt$y), ncol=2))
		} else if(radius<=0) {
			stop("radius should be >0")
		} else {
			for (i in 1:dim(object)[1]) {
				pos <- object[i,c("x","y")]
				pos.dist <- distanceFromPoints(the.raster, pos)
				ttt[i,"xxx"] <- mean(the.raster[pos.dist<radius]) # mean value within radius
				if (i%%100==0) message(paste("pos",i)) 
			}
		}
		names(ttt)[which(names(ttt)=="xxx")] <- varname
		return(ttt)
	}
)


find.ars.scale <- function(object, ...) attributes(object)
setGeneric("find.ars.scale")


setMethod("find.ars.scale", "data.frame",
	function(object, rad.min=2000, rad.max=12000, by=1000, maxt=10000000000, unit="hours") {
		ars.data <- data.frame()
		for (rad in seq(rad.min, rad.max, by)) {
			object.res.t <- get.res.t(object, the.rad=rad, unit=unit, maxt=maxt)
			mean.na.rm <- function(x) mean(x, na.rm=TRUE)
			var.log.na.rm <- function(x) var(log10(x), na.rm=TRUE)
			rt <- tapply(object.res.t$res.t, INDEX=list(object.res.t$id), FUN="mean.na.rm")
			var.log.rt <- tapply(object.res.t$res.t, INDEX=list(object.res.t$id), FUN="var.log.na.rm")
			out <- cbind("id"=names(rt), "r"=rad, as.data.frame(rt), "unit"=unit, as.data.frame(var.log.rt))
			ars.data <- rbind(ars.data, out)
		}
		return(ars.data)
	}
)


setMethod("find.ars.scale", "SpatialPointsDataFrame",
	function(object, rad.min=2000, rad.max=12000, by=1000, unit="hours") {
		if(length(grep("utm", proj4string(object), ignore.case=TRUE))<1) stop("Input object must use UTM coordinates")		
		object <- as.data.frame(object)
		ars.data <- data.frame()
		for (rad in seq(rad.min, rad.max, by)) {
			object.res.t <- get.res.t(object, the.rad=rad, unit=unit, maxt=maxt)
			mean.na.rm <- function(x) mean(x, na.rm=TRUE)
			var.log.na.rm <- function(x) var(log10(x), na.rm=TRUE)
			rt <- tapply(object.res.t$res.t, INDEX=list(object.res.t$id), FUN="mean.na.rm")
			var.log.rt <- tapply(object.res.t$res.t, INDEX=list(object.res.t$id), FUN="var.log.na.rm")
			out <- cbind("id"=names(rt), "r"=rad, as.data.frame(rt), "unit"=unit, as.data.frame(var.log.rt))
			ars.data <- rbind(ars.data, out)
		}
		return(ars.data)
	}
)

